'use strict';

/**
 * @ngdoc overview
 * @name ukjgsRegistrationApp
 * @description
 * # ukjgsRegistrationApp
 *
 * Main module of the application.
 */
angular
  .module('ukjgsRegistrationApp', []);
